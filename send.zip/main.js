var http = require('http')
const fs = require('fs')
// const csv = require('csv-parser')

//include express module or package
const express = require('express');
// var arr = {'processed/transactions_2.csv', 'prprocessed/transactions_3.csv'}
const files = fs.readdirSync('processed/');

console.log(files)
console.log(files.length)
const dataFrames = []

function getLatestOnToken(token, df)
{
    let line = ''
    for(let i = 0; i < df.length; i++)
    {
        line = df[i].split(' ')
        for(let j = 0 ; j < line.length; j++)
        {
            if (line[j] === token)
            {
                console.log('this is the latest transaction of current token')

                console.log(df[i])
                return
            }
        }
    
    }
}

for(let i = 0;  i < files.length; i++)
{
    dataFrames[i] =  fs.readFileSync('processed/' + files[i], 'utf-8')
}

// console.log(dataFrames[0])
let i = 0
getLatestOnToken("BTC", dataFrames[0])
console.log("printing first row let's see ")
console.log(dataFrames[0][0])
const app = express();
app.get('/', (req, res) =>{
    res.send('Hello World');
})
app.listen(6060, () => console.log('Listening on port 6060!'));
