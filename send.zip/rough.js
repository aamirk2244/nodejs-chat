function mainFn(params) { // do NOT change this line or  name of this function
   
    var max = 0
    var maxSum = []
    var length = params.length

    for(let i = 0; i < length; i++)
    {
        if(i + 2 < length)
        {
            maxSum.push(params[i] + params[i+1] + params[i+2])
      
        }
        
    }
    console.log(maxSum)
    maxSum.sort()
     return maxSum.pop(-1);          
   }


   console.log(mainFn([2,0,1,100,200,10,7,2,300,2,10]))